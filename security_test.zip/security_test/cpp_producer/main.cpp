#include <pcap.h>

#include <chrono>
#include <ctime>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

namespace fs = std::filesystem;

struct CaptureConfig {
    // 网卡设备名（Npcap/WinPcap 设备路径），由命令行第一个参数传入。
    std::string device_name;
    // 抓包文件输出目录。
    std::string output_dir = "captures";
    // BPF 过滤表达式（例如 "tcp or udp"），为空表示不过滤。
    std::string bpf_filter = "";
    // 单包截取长度上限（字节）。
    int snaplen = 65535;
    // 是否开启混杂模式：1=开启，可捕获非本机目的包。
    int promisc = 1;
    // 抓包读取超时（毫秒），影响 pcap_dispatch 返回节奏。
    int timeout_ms = 1000;
    // 单个 pcap 文件最大体积，超过后触发轮转。
    uint64_t max_file_bytes = 50ULL * 1024ULL * 1024ULL;
    // 单个 pcap 文件最长写入秒数，超过后触发轮转。
    int rotate_seconds = 60;
};

struct CaptureContext {
    // pcap 抓包会话句柄（pcap_open_live 返回）。
    pcap_t* handle = nullptr;
    // 当前输出文件句柄（pcap_dump_open 返回）。
    pcap_dumper_t* dumper = nullptr;
    // 抓包配置快照。
    CaptureConfig cfg;
    // 当前正在写入的 pcap 文件完整路径。
    std::string current_file;
    // 当前文件开始写入的时间点（用于时间轮转）。
    std::chrono::system_clock::time_point file_start_time;
    // 文件序号（用于文件名后缀）。
    int file_index = 1;
    // 已处理数据包计数（用于周期 flush）。
    uint64_t packet_count = 0;
};

// 获取当前本地时间并按指定格式输出字符串（用于日志和文件名）。
// 参数 fmt: 时间格式串（例如 "%Y%m%d_%H%M%S"）。
static std::string now_string(const char* fmt) {
    auto now = std::chrono::system_clock::now();
    std::time_t t = std::chrono::system_clock::to_time_t(now);
    std::tm tm {};
#ifdef _WIN32
    localtime_s(&tm, &t);
#else
    localtime_r(&t, &tm);
#endif
    std::ostringstream oss;
    oss << std::put_time(&tm, fmt);
    return oss.str();
}

// 生成当前轮转文件名：capture_日期时间_序号.pcap。
static std::string build_capture_filename(const CaptureContext& ctx) {
    std::ostringstream oss;
    oss << "capture_" << now_string("%Y%m%d_%H%M%S") << "_" << std::setw(3)
        << std::setfill('0') << ctx.file_index << ".pcap";
    return (fs::path(ctx.cfg.output_dir) / oss.str()).string();
}

// 打开新的 pcap 输出文件；若已有文件则先 flush 并关闭。
static bool open_new_dumper(CaptureContext& ctx) {
    if (ctx.dumper != nullptr) {
        pcap_dump_flush(ctx.dumper);
        pcap_dump_close(ctx.dumper);
        ctx.dumper = nullptr;
    }

    fs::create_directories(ctx.cfg.output_dir);
    ctx.current_file = build_capture_filename(ctx);
    ctx.dumper = pcap_dump_open(ctx.handle, ctx.current_file.c_str());
    if (!ctx.dumper) {
        std::cerr << "Failed to open dump file: " << ctx.current_file
                  << ", error: " << pcap_geterr(ctx.handle) << "\n";
        return false;
    }
    ctx.file_start_time = std::chrono::system_clock::now();

    std::cout << "[ROTATE] writing to: " << ctx.current_file << "\n";
    return true;
}

// 判断是否需要轮转文件（按时间或文件大小阈值）。
static bool should_rotate(const CaptureContext& ctx) {
    auto now = std::chrono::system_clock::now();
    auto elapsed =
        std::chrono::duration_cast<std::chrono::seconds>(now - ctx.file_start_time)
            .count();
    if (elapsed >= ctx.cfg.rotate_seconds) {
        return true;
    }

    if (!ctx.current_file.empty() && fs::exists(ctx.current_file)) {
        std::error_code ec;
        uint64_t sz = fs::file_size(ctx.current_file, ec);
        if (!ec && sz >= ctx.cfg.max_file_bytes) {
            return true;
        }
    }
    return false;
}

// 抓包回调：写入当前文件、定期刷盘，并在满足条件时切换新文件。
// 参数 user/header/packet_data 为 libpcap 标准回调参数：
// - user: 传入的上下文指针（这里是 CaptureContext）
// - header: 当前包的元数据（时间戳、长度）
// - packet_data: 当前包原始字节
static void packet_handler(u_char* user, const struct pcap_pkthdr* header,
                           const u_char* packet_data) {
    auto* ctx = reinterpret_cast<CaptureContext*>(user);
    pcap_dump(reinterpret_cast<u_char*>(ctx->dumper), header, packet_data);
    ++ctx->packet_count;

    // 每 500 包主动 flush，降低异常退出时的数据丢失风险。
    if ((ctx->packet_count % 500) == 0) {
        pcap_dump_flush(ctx->dumper);
    }

    if (should_rotate(*ctx)) {
        ++ctx->file_index;
        open_new_dumper(*ctx);
    }
}

// 打印命令行使用说明。
static void print_usage() {
    std::cout << "Usage:\n"
              << "  producer.exe <device_name> [output_dir] [filter]\n\n"
              << "Example:\n"
              << "  producer.exe \"\\\\Device\\\\NPF_{XXXX}\" captures \"tcp or udp\"\n";
}

// 程序入口：初始化抓包、应用过滤器、持续采集并按策略轮转保存。
int main(int argc, char* argv[]) {
    // 未提供设备名时，输出帮助并列出可用网卡，便于用户复制使用。
    // 参数不足：至少要传入网卡设备名（argv[1]）。
    if (argc < 2) {
        print_usage();
        // 使用 Npcap 枚举本机可用网卡，便于用户复制设备名后重新执行。
        char errbuf[PCAP_ERRBUF_SIZE] {};
        pcap_if_t* alldevs = nullptr;
        if (pcap_findalldevs(&alldevs, errbuf) == -1) {
            std::cerr << "pcap_findalldevs failed: " << errbuf << "\n";
            return 1;
        }
        std::cout << "\nAvailable devices:\n";
        for (pcap_if_t* d = alldevs; d != nullptr; d = d->next) {
            std::cout << "  - " << (d->name ? d->name : "<no-name>");
            if (d->description) {
                std::cout << " | " << d->description;
            }
            std::cout << "\n";
        }
        pcap_freealldevs(alldevs);
        return 1;
    }

    // 构造抓包上下文，并从命令行覆盖默认配置。
    CaptureContext ctx;
    // argv[1]：必填，Npcap 设备名（如 \\Device\\NPF_{...}）。
    ctx.cfg.device_name = argv[1];
    // argv[2]：可选，pcap 输出目录。
    if (argc >= 3) {
        ctx.cfg.output_dir = argv[2];
    }
    // argv[3]：可选，BPF 过滤表达式（如 "tcp or udp"）。
    if (argc >= 4) {
        ctx.cfg.bpf_filter = argv[3];
    }

    // 打开实时抓包句柄（核心入口）：
    // - device_name: 设备名
    // - snaplen: 单包截取最大长度
    // - promisc: 是否混杂模式
    // - timeout_ms: 读取超时
    // - errbuf: 失败时错误信息
    char errbuf[PCAP_ERRBUF_SIZE] {};
    ctx.handle = pcap_open_live(ctx.cfg.device_name.c_str(), ctx.cfg.snaplen,
                                ctx.cfg.promisc, ctx.cfg.timeout_ms, errbuf);
    // 句柄为空表示抓包会话创建失败（设备名错误、权限不足、驱动异常等）。
    if (!ctx.handle) {
        std::cerr << "pcap_open_live failed: " << errbuf << "\n";
        return 1;
    }

    // 仅当用户传入过滤器时才编译并应用 BPF 规则。
    if (!ctx.cfg.bpf_filter.empty()) {
        bpf_u_int32 net = 0;
        bpf_u_int32 mask = 0;
        pcap_lookupnet(ctx.cfg.device_name.c_str(), &net, &mask, errbuf);

        bpf_program fp {};
        // 先把字符串过滤器编译成内核可执行过滤程序。
        if (pcap_compile(ctx.handle, &fp, ctx.cfg.bpf_filter.c_str(), 1, net) == -1) {
            std::cerr << "pcap_compile failed: " << pcap_geterr(ctx.handle) << "\n";
            pcap_close(ctx.handle);
            return 1;
        }
        // 把已编译过滤程序挂到抓包句柄。
        if (pcap_setfilter(ctx.handle, &fp) == -1) {
            std::cerr << "pcap_setfilter failed: " << pcap_geterr(ctx.handle) << "\n";
            pcap_freecode(&fp);
            pcap_close(ctx.handle);
            return 1;
        }
        pcap_freecode(&fp);
    }

    if (!open_new_dumper(ctx)) {
        pcap_close(ctx.handle);
        return 1;
    }

    std::cout << "Capture started on device: " << ctx.cfg.device_name << "\n"
              << "Output dir: " << ctx.cfg.output_dir << "\n"
              << "Rotate by size: " << (ctx.cfg.max_file_bytes / (1024 * 1024))
              << " MB, or by time: " << ctx.cfg.rotate_seconds << " sec\n";

    int ret = 0;
    while (true) {
        // Use dispatch loop so we can rotate on time even when no packets arrive.
        int dispatch_ret =
            pcap_dispatch(ctx.handle, -1, packet_handler, reinterpret_cast<u_char*>(&ctx));
        // -1 代表运行时错误，立即中断主循环。
        if (dispatch_ret == -1) {
            std::cerr << "pcap_dispatch failed: " << pcap_geterr(ctx.handle) << "\n";
            ret = -1;
            break;
        }
        // -2 代表捕获被中止（例如 breakloop），正常退出循环。
        if (dispatch_ret == -2) {
            break;
        }

        if (should_rotate(ctx)) {
            ++ctx.file_index;
            if (!open_new_dumper(ctx)) {
                ret = -1;
                break;
            }
        }
    }

    if (ctx.dumper) {
        pcap_dump_flush(ctx.dumper);
        pcap_dump_close(ctx.dumper);
    }
    if (ctx.handle) {
        pcap_close(ctx.handle);
    }
    return ret == -1 ? 1 : 0;
}
