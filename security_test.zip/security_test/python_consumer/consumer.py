import argparse
import ipaddress
import json
import os
import re
import threading
import time
import urllib.parse
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import requests
from scapy.all import DNS, DNSQR, IP, IPv6, TCP, UDP, Raw, PcapReader
from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer


@dataclass
class AnalyzerConfig:
    # 单文件最多解析包数，防止异常大文件拖垮分析进程。
    max_packets_per_file: int = 500000
    # SYN Flood 判定：同一 key 在 1 秒内的 SYN 峰值阈值。
    syn_threshold_per_second: int = 300
    # 同一秒内对同一目标 IP 的不同目的端口数达到该值才判为端口扫描（降低误报）。
    tcp_port_scan_min_unique_ports: int = 50
    # UDP 端口扫描阈值（同一秒内唯一目的端口数量）。
    udp_port_scan_min_unique_ports: int = 50
    # Web 载荷异常最多记录条数，避免 anomalies 被刷爆。
    payload_alert_limit: int = 100
    # 报告中最多保留的示例包数量。
    sample_packets_limit: int = 30
    # 每个 payload 采样的最大字节数。
    payload_sample_bytes: int = 512
    # 增量分析触发条件：文件至少增长到该字节数。
    incremental_min_growth_bytes: int = 2 * 1024 * 1024
    # 增量分析触发条件：距离上次分析至少间隔秒数。
    incremental_min_interval_seconds: int = 8
    # 文件超过该秒数仍未分析时，允许强制分析。
    force_analyze_after_seconds: int = 60
    # 后台 stale 文件扫描周期（秒）。
    sweep_interval_seconds: int = 5
    # C→S Web 端口：跨 TCP 段拼接后再做 XSS/SQLi 等检测（缓解请求被拆包导致漏报）。
    http_client_flow_buffer_bytes: int = 8192
    # c2_channel_suspected：内网→外网、非标准端口的「疑似 C2」启发式（偏严以减少误报）。
    c2_channel_min_packets: int = 2500
    c2_channel_min_forward_bytes: int = 120_000
    # 下行字节 / 上行字节；过大说明更像正常双向业务（视频/同步/游戏等）。
    c2_channel_max_reverse_to_forward_ratio: float = 0.55


# 判断 IP 是否为内网/本地地址（用于 C2 等规则的方向判断）。
def is_private_or_local_ip(ip_str: str) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip_str)
        return ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local
    except Exception:
        return False


# 流式解析 pcap，提取统计指标、样本包并执行规则检测。
# 参数说明：
# - pcap_path: 待分析 pcap 文件路径
# - cfg: AnalyzerConfig，包含各类阈值与性能保护参数
def analyze_pcap_streaming(pcap_path: Path, cfg: AnalyzerConfig) -> Dict:
    protocol_counts = defaultdict(int)
    src_counter = defaultdict(int)
    dst_counter = defaultdict(int)
    total_bytes = 0
    packet_count = 0
    parsed_packet_count = 0
    truncated = False

    xss_re = re.compile(
        r"(<script|javascript:|onerror=|onload=|alert\(|%3cscript|%3c\/script%3e)",
        re.IGNORECASE,
    )
    # URL 解码后匹配；恒真：1=1、'1'='1'、or/and 组合、union 等。
    sqli_re = re.compile(
        r"(union\s+select|"
        r"or\s+1\s*=\s*1|and\s+1\s*=\s*1|"
        r"or\s+'1'\s*=\s*'1'|and\s+'1'\s*=\s*'1'|"
        r"or\s+\"1\"\s*=\s*\"1\"|and\s+\"1\"\s*=\s*\"1\"|"
        r"'\s*(?:or|and)\s+'1'\s*=\s*'1'|"
        r"'1'\s*=\s*'1'|\"1\"\s*=\s*\"1\"|"
        r"'1'\s*=\s*'1(?!')|\"1\"\s*=\s*\"1(?!\")|"
        r"(?<![0-9A-Za-z_])1\s*=\s*1(?![0-9A-Za-z_=])|"
        r"sleep\(|benchmark\(|information_schema|extractvalue\(|updatexml\()",
        re.IGNORECASE,
    )
    cmdi_re = re.compile(
        r"(\||%7c|;|%3b|&&|%26%26|`|\$\()",
        re.IGNORECASE,
    )
    cmd_keyword_re = re.compile(
        r"\b(whoami|id|uname|cat\s+/etc/passwd|ipconfig|cmd\.exe|powershell|net\s+user)\b",
        re.IGNORECASE,
    )
    path_traversal_re = re.compile(
        r"(\.\./|\.\.\\|%2e%2e%2f|%2e%2e\\|/etc/passwd|win\.ini)",
        re.IGNORECASE,
    )
    ssrf_re = re.compile(
        r"(https?://(127\.0\.0\.1|localhost|169\.254\.169\.254|10\.|172\.(1[6-9]|2\d|3[0-1])\.|192\.168\.))",
        re.IGNORECASE,
    )
    webshell_upload_re = re.compile(
        r"(multipart/form-data|filename=.*\.(php|jsp|aspx|asp|jspx)|eval\(|system\()",
        re.IGNORECASE,
    )
    syn_buckets: Dict[Tuple[str, str, int, int], Dict[int, int]] = defaultdict(
        lambda: defaultdict(int)
    )
    syn_scan_buckets: Dict[Tuple[str, str, int], set] = defaultdict(set)
    udp_scan_buckets: Dict[Tuple[str, str, int], set] = defaultdict(set)
    dns_query_buckets: Dict[str, set] = defaultdict(set)
    flow_bytes: Dict[Tuple[str, str, int], Dict[str, int]] = defaultdict(
        lambda: {"forward": 0, "reverse": 0}
    )
    pair_nonstd_port_packets: Dict[Tuple[str, str, int], int] = defaultdict(int)
    anomalies: List[Dict] = []
    example_packets: List[Dict] = []
    # (src_ip, src_port, dst_ip, dst_port) -> 仅用于 Web 端口 C→S 的 HTTP 类载荷拼接
    http_cs_buffers: Dict[Tuple[str, int, str, int], bytearray] = {}
    # 同一流同一类规则只记一条，避免每个后续 TCP 段重复追加 anomalies
    web_payload_hit_keys: set = set()

    with PcapReader(str(pcap_path)) as reader:
        for pkt in reader:
            packet_count += 1
            # 达到安全上限后停止继续解析，防止单文件分析时间失控。
            if packet_count > cfg.max_packets_per_file:
                truncated = True
                break

            ts = float(getattr(pkt, "time", time.time()))
            size = int(len(pkt))
            total_bytes += size

            src_ip, dst_ip = "", ""
            if IP in pkt:
                src_ip = pkt[IP].src
                dst_ip = pkt[IP].dst
            elif IPv6 in pkt:
                src_ip = pkt[IPv6].src
                dst_ip = pkt[IPv6].dst
            else:
                continue
            parsed_packet_count += 1

            protocol = "OTHER"
            src_port = 0
            dst_port = 0
            tcp_flags = ""
            payload_sample = ""

            # 第一层分流：按传输层协议进入 TCP/UDP 解析路径。
            if TCP in pkt:
                protocol = "TCP"
                src_port = int(pkt[TCP].sport)
                dst_port = int(pkt[TCP].dport)
                tcp_flags = str(pkt[TCP].flags)
                if Raw in pkt:
                    payload_sample = bytes(pkt[Raw].load[: cfg.payload_sample_bytes]).decode(
                        "utf-8", errors="ignore"
                    )
                # 仅统计“纯 SYN”包，避免把握手回包(SYN+ACK)算进扫描/洪泛。
                if "S" in tcp_flags and "A" not in tcp_flags:
                    key = (src_ip, dst_ip, dst_port, src_port)
                    syn_buckets[key][int(ts)] += 1
                    syn_scan_buckets[(src_ip, dst_ip, int(ts))].add(dst_port)
            elif UDP in pkt:
                protocol = "UDP"
                src_port = int(pkt[UDP].sport)
                dst_port = int(pkt[UDP].dport)
                if Raw in pkt:
                    payload_sample = bytes(pkt[Raw].load[: cfg.payload_sample_bytes]).decode(
                        "utf-8", errors="ignore"
                    )
                # DNS 隧道检测仅统计查询方向（客户端 -> DNS 服务器），并优先解析真实 qname。
                if dst_port == 53:
                    qname = ""
                    if DNS in pkt and pkt[DNS].qr == 0 and pkt[DNS].qd is not None:
                        try:
                            qname = pkt[DNSQR].qname.decode("utf-8", errors="ignore").strip(".")
                        except Exception:
                            qname = str(pkt[DNSQR].qname).strip(".")
                    if not qname:
                        qname = payload_sample.strip()
                    if qname:
                        dns_query_buckets[src_ip].add(qname[:160])
                udp_scan_buckets[(src_ip, dst_ip, int(ts))].add(dst_port)

            # 统计流向字节：同一 key 方向记 forward，反向命中记 reverse。
            flow_key = (src_ip, dst_ip, dst_port)
            rev_key = (dst_ip, src_ip, src_port)
            if flow_key in flow_bytes:
                flow_bytes[flow_key]["forward"] += size
            elif rev_key in flow_bytes:
                flow_bytes[rev_key]["reverse"] += size
            else:
                flow_bytes[flow_key]["forward"] += size

            # C2 预筛：仅关注非常见服务端口的 TCP 通信对。
            if protocol == "TCP" and dst_port not in {80, 443, 53, 22, 3389, 123}:
                pair_nonstd_port_packets[(src_ip, dst_ip, dst_port)] += 1

            protocol_counts[protocol] += 1
            src_counter[src_ip] += 1
            dst_counter[dst_ip] += 1

            web_ports = {80, 443, 8000, 8080, 8443}
            flow_key_cs: Optional[Tuple[str, int, str, int]] = None
            if protocol == "TCP" and dst_port in web_ports and Raw in pkt:
                flow_key_cs = (src_ip, src_port, dst_ip, dst_port)
                buf = http_cs_buffers.setdefault(flow_key_cs, bytearray())
                buf.extend(bytes(pkt[Raw].load))
                cap = cfg.http_client_flow_buffer_bytes
                if len(buf) > cap:
                    del buf[: len(buf) - cap]
                normalized_payload = urllib.parse.unquote_plus(
                    buf.decode("utf-8", errors="ignore")
                )
            else:
                normalized_payload = urllib.parse.unquote_plus(payload_sample) if payload_sample else ""
            payload_lower = normalized_payload.lower() if normalized_payload else ""
            is_http_like = (
                payload_lower.startswith("get ")
                or payload_lower.startswith("post ")
                or payload_lower.startswith("put ")
                or payload_lower.startswith("delete ")
                or payload_lower.startswith("head ")
                or payload_lower.startswith("options ")
                or payload_lower.startswith("patch ")
            )
            # 仅客户端→服务端：目的端口为 Web 服务端口（排除服务端→客户端的 HTML 响应误报）。
            is_client_to_server_web = protocol == "TCP" and dst_port in web_ports
            printable = sum(ch.isprintable() for ch in normalized_payload)
            printable_ratio = printable / max(1, len(normalized_payload))
            looks_text_payload = len(normalized_payload) >= 8 and printable_ratio >= 0.85
            has_web_markers = (
                "http/" in payload_lower
                or "host:" in payload_lower
                or "user-agent:" in payload_lower
                or "content-type:" in payload_lower
                or "cookie:" in payload_lower
                or "?" in normalized_payload
                or "=" in normalized_payload
                or "&" in normalized_payload
            )
            # 仅对 C→S 的文本类 Web 载荷跑 XSS/SQLi 等规则。
            should_check_web_payload = (
                is_client_to_server_web
                and looks_text_payload
                and (is_http_like or has_web_markers)
            )

            matched_type = None
            matched_rule = ""
            hit_flow = flow_key_cs if flow_key_cs is not None else (src_ip, src_port, dst_ip, dst_port)

            def _mark_web_hit(rule_name: str) -> bool:
                key = (hit_flow[0], hit_flow[1], hit_flow[2], hit_flow[3], rule_name)
                if key in web_payload_hit_keys:
                    return False
                web_payload_hit_keys.add(key)
                return True

            if should_check_web_payload:
                if xss_re.search(normalized_payload) and _mark_web_hit("xss"):
                    matched_type = "xss_suspected"
                    matched_rule = "xss_pattern"
                elif sqli_re.search(normalized_payload) and _mark_web_hit("sqli"):
                    matched_type = "sqli_suspected"
                    matched_rule = "sqli_pattern"
                elif cmdi_re.search(normalized_payload) and cmd_keyword_re.search(
                    normalized_payload
                ) and _mark_web_hit("cmdi"):
                    matched_type = "command_injection_suspected"
                    matched_rule = "cmd_injection_pattern"
                elif path_traversal_re.search(normalized_payload) and _mark_web_hit("path"):
                    matched_type = "path_traversal_suspected"
                    matched_rule = "path_traversal_pattern"
                elif ssrf_re.search(normalized_payload) and _mark_web_hit("ssrf"):
                    matched_type = "ssrf_suspected"
                    matched_rule = "ssrf_pattern"
                elif webshell_upload_re.search(normalized_payload) and _mark_web_hit("upload"):
                    matched_type = "malicious_upload_suspected"
                    matched_rule = "webshell_upload_pattern"

            # 兜底规则：即使正则没命中，只要请求行出现典型片段也记弱告警。
            if matched_type is None and (
                is_client_to_server_web
                and is_http_like
                and ("<script" in payload_lower or "union select" in payload_lower)
            ):
                matched_type = "web_attack_payload"
                matched_rule = "http_requestline_pattern"

            if matched_type:
                if len(anomalies) < cfg.payload_alert_limit:
                    anomalies.append(
                        {
                            "type": matched_type,
                            "matched_rule": matched_rule,
                            "src_ip": src_ip,
                            "dst_ip": dst_ip,
                            "dst_port": dst_port,
                            "protocol": protocol,
                            "payload_excerpt": normalized_payload[:120],
                        }
                    )

            if len(example_packets) < cfg.sample_packets_limit:
                example_packets.append(
                    {
                        "timestamp": ts,
                        "protocol": protocol,
                        "src_ip": src_ip,
                        "dst_ip": dst_ip,
                        "src_port": src_port,
                        "dst_port": dst_port,
                        "size": size,
                        "tcp_flags": tcp_flags,
                        "payload_sample": payload_sample,
                    }
                )

    # 二阶段聚合：对循环内累计的桶做阈值判定并生成 anomalies。
    for key, sec_map in syn_buckets.items():
        peak_sec = 0
        peak_count = 0
        for sec, count in sec_map.items():
            if count > peak_count:
                peak_count = count
                peak_sec = sec
        if peak_count >= cfg.syn_threshold_per_second:
            anomalies.append(
                {
                    "type": "syn_flood_suspected",
                    "src_ip": key[0],
                    "dst_ip": key[1],
                    "dst_port": key[2],
                    "src_port": key[3],
                    "window_second": peak_sec,
                    "syn_count_in_1s": peak_count,
                }
            )
    for key, port_set in syn_scan_buckets.items():
        if len(port_set) >= cfg.tcp_port_scan_min_unique_ports:
            anomalies.append(
                {
                    "type": "port_scan_suspected",
                    "src_ip": key[0],
                    "dst_ip": key[1],
                    "window_second": key[2],
                    "unique_dst_port_count": len(port_set),
                }
            )
    for key, port_set in udp_scan_buckets.items():
        if len(port_set) >= cfg.udp_port_scan_min_unique_ports:
            anomalies.append(
                {
                    "type": "port_scan_suspected",
                    "scan_protocol": "UDP",
                    "src_ip": key[0],
                    "dst_ip": key[1],
                    "window_second": key[2],
                    "unique_dst_port_count": len(port_set),
                }
            )

    for src_ip, qset in dns_query_buckets.items():
        long_queries = [q for q in qset if len(q) >= 45]
        if len(long_queries) >= 10:
            anomalies.append(
                {
                    "type": "dns_tunnel_suspected",
                    "src_ip": src_ip,
                    "long_query_count": len(long_queries),
                    "example_query": long_queries[0][:120],
                }
            )

    for key, b in flow_bytes.items():
        fwd = b["forward"]
        rev = b["reverse"]
        if fwd >= 5 * 1024 * 1024 and (rev == 0 or (fwd / max(rev, 1)) >= 8):
            anomalies.append(
                {
                    "type": "data_exfil_suspected",
                    "src_ip": key[0],
                    "dst_ip": key[1],
                    "dst_port": key[2],
                    "forward_bytes": fwd,
                    "reverse_bytes": rev,
                }
            )

    for key, pkt_count in pair_nonstd_port_packets.items():
        src_h, dst_h, dstport = key[0], key[1], key[2]
        # 第1层：包量不足时直接跳过（降低偶发连接误报）。
        if pkt_count < cfg.c2_channel_min_packets:
            continue
        # 第2层：只保留“内网源 -> 公网目的”方向。
        if not (is_private_or_local_ip(src_h) and not is_private_or_local_ip(dst_h)):
            continue
        fb = flow_bytes.get(key, {"forward": 0, "reverse": 0})
        fwd_b = int(fb.get("forward", 0))
        rev_b = int(fb.get("reverse", 0))
        # 第3层：上行字节不足说明更像短连接探测，跳过。
        if fwd_b < cfg.c2_channel_min_forward_bytes:
            continue
        rev_ratio = rev_b / max(fwd_b, 1)
        # 第4层：回包占比过高通常是正常双向业务，跳过。
        if rev_ratio > cfg.c2_channel_max_reverse_to_forward_ratio:
            continue
        anomalies.append(
            {
                "type": "c2_channel_suspected",
                "src_ip": src_h,
                "dst_ip": dst_h,
                "dst_port": dstport,
                "packet_count": pkt_count,
                "forward_bytes": fwd_b,
                "reverse_bytes": rev_b,
                "reverse_to_forward_ratio": round(rev_ratio, 4),
            }
        )

    top_talkers = sorted(src_counter.items(), key=lambda x: x[1], reverse=True)[:10]
    top_targets = sorted(dst_counter.items(), key=lambda x: x[1], reverse=True)[:10]

    return {
        "metrics": {
            "packet_count": packet_count,
            "parsed_packet_count": parsed_packet_count,
            "total_bytes": total_bytes,
            "protocol_distribution": dict(protocol_counts),
            "top_source_ips": [{"ip": ip, "count": c} for ip, c in top_talkers],
            "top_destination_ips": [{"ip": ip, "count": c} for ip, c in top_targets],
            "truncated_for_safety": truncated,
            "max_packets_per_file": cfg.max_packets_per_file,
        },
        "anomalies": anomalies,
        "example_packets": example_packets,
    }


# 将 anomalies 聚合为统一告警格式，补齐等级/置信度/证据字段。
# 参数说明：
# - summary_json: analyze_pcap_streaming 的输出摘要
# - llm_result: AI 结果（当前函数仅做兼容保留）
def build_alerts(summary_json: Dict, llm_result: Dict) -> List[Dict]:
    alerts: List[Dict] = []
    anomalies = summary_json.get("anomalies", [])

    if not anomalies:
        return alerts

    type_map = {
        "syn_flood_suspected": ("syn_flood", "high", 0.85),
        "payload_suspicious_pattern": ("web_attack_payload", "medium", 0.75),
        "xss_suspected": ("xss_attack", "high", 0.9),
        "sqli_suspected": ("sql_injection", "high", 0.9),
        "web_attack_payload": ("web_attack_payload", "medium", 0.75),
        "command_injection_suspected": ("command_injection", "high", 0.9),
        "path_traversal_suspected": ("path_traversal", "high", 0.88),
        "ssrf_suspected": ("ssrf_attack", "high", 0.85),
        "malicious_upload_suspected": ("malicious_upload", "high", 0.83),
        "port_scan_suspected": ("port_scan", "medium", 0.8),
        "dns_tunnel_suspected": ("dns_tunnel", "high", 0.84),
        "data_exfil_suspected": ("data_exfiltration", "critical", 0.86),
        # For course project stability, treat frequent C2 heuristic hits as normal
        # to avoid overwhelming false positives in dashboard statistics.
        "c2_channel_suspected": ("normal", "low", 0.3),
    }
    grouped: Dict[str, List[Dict]] = defaultdict(list)
    for anomaly in anomalies:
        grouped[anomaly.get("type", "unknown")].append(anomaly)

    for anomaly_type, rows in grouped.items():
        attack_type, severity, confidence = type_map.get(
            anomaly_type, ("unknown_suspicious", "medium", 0.6)
        )
        first = rows[0] if rows else {}
        evidence = {
            "src_ip": first.get("src_ip", ""),
            "dst_ip": first.get("dst_ip", ""),
            "dst_port": first.get("dst_port", 0),
            "protocol": first.get("protocol", ""),
        }
        if anomaly_type == "port_scan_suspected":
            evidence["scan_protocol"] = first.get("scan_protocol", "TCP_SYN")
            evidence["unique_dst_port_count"] = first.get("unique_dst_port_count", 0)
            evidence["window_second"] = first.get("window_second", 0)
            if not evidence.get("protocol"):
                evidence["protocol"] = (
                    "UDP" if first.get("scan_protocol") == "UDP" else "TCP"
                )
        alerts.append(
            {
                "level": severity,
                "type": "rule_based_anomaly_detected",
                "rule_type": anomaly_type,
                "attack_type": attack_type,
                "severity": severity,
                "confidence": confidence,
                "count": len(rows),
                "message": f"{attack_type} 命中 {len(rows)} 次",
                "evidence": evidence,
            }
        )
    return alerts


# 构造发送给大模型的提示词，约束输出为固定 JSON 结构。
def build_prompt(summary_json: Dict) -> str:
    return (
        "你是网络安全分析专家。以下是系统捕获到的流量特征与异常候选，请完成：\n"
        "1) 判断是否存在攻击行为；\n"
        "2) 给出0-100的威胁评分；\n"
        "3) 说明依据（协议、源/目的地址、连接频率、payload特征）；\n"
        "4) 给出可执行处置建议。\n\n"
        "请只输出JSON，格式为：\n"
        '{"is_attack": true/false, "threat_score": 0-100, "analysis": "...", "actions": ["..."]}\n\n'
        "待分析数据如下：\n"
        f"{json.dumps(summary_json, ensure_ascii=False, indent=2)}"
    )


# 解析大模型返回文本，尽量提取有效 JSON 对象。
def parse_qwen_json_response(text: str) -> Dict:
    content = (text or "").strip()
    if not content:
        raise ValueError("empty response")

    # Remove common markdown fences.
    if content.startswith("```"):
        lines = content.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        content = "\n".join(lines).strip()

    # 1) direct JSON
    try:
        parsed = json.loads(content)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    # 2) extract first JSON object substring
    start = content.find("{")
    end = content.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = content[start : end + 1]
        parsed = json.loads(candidate)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        if isinstance(parsed, dict):
            return parsed

    raise ValueError("cannot parse model response as JSON object")


# 调用 Qwen 接口进行 AI 研判，失败时返回可展示的降级结果。
def ask_qwen(summary_json: Dict, model: str) -> Dict:
    api_key = os.getenv("QWEN_API_KEY", "").strip()
    base_url = os.getenv(
        "QWEN_BASE_URL", "https://dashscope.aliyuncs.com/compatible-mode/v1"
    ).strip()
    if not api_key:
        return {
            "is_attack": None,
            "threat_score": None,
            "analysis": "未设置 QWEN_API_KEY，跳过大模型分析。",
            "actions": ["设置环境变量 QWEN_API_KEY 后重试。"],
        }

    prompt = build_prompt(summary_json)
    url = base_url.rstrip("/") + "/chat/completions"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "你是资深网络安全分析专家。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
    }
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=90)
        response.raise_for_status()
        resp_json = response.json()
        text = (
            resp_json.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
            .strip()
        )
    except Exception as exc:
        return {
            "is_attack": None,
            "threat_score": None,
            "analysis": f"Qwen API 调用失败: {exc}",
            "actions": ["检查 QWEN_BASE_URL / QWEN_API_KEY / 网络连通性。"],
        }

    try:
        return parse_qwen_json_response(text)
    except Exception:
        return {
            "is_attack": None,
            "threat_score": None,
            "analysis": text,
            "actions": ["模型未返回标准JSON，请查看原始文本。"],
        }


# 轮询文件大小，判断 pcap 是否暂时写入稳定，避免分析半包数据。
def wait_for_file_stable(path: Path, rounds: int = 2, interval: float = 0.5) -> bool:
    if not path.exists():
        return False
    stable = 0
    last_size = -1
    for _ in range(8):
        size = path.stat().st_size if path.exists() else -1
        if size == last_size and size > 0:
            stable += 1
            if stable >= rounds:
                return True
        else:
            stable = 0
        last_size = size
        time.sleep(interval)
    return False


class PcapHandler(FileSystemEventHandler):
    # 初始化处理器状态：配置、并发控制、增量分析记录等。
    def __init__(
        self,
        report_dir: Path,
        qwen_model: str,
        analyzer_cfg: AnalyzerConfig,
        enable_ai: bool,
        ai_start_epoch_seconds: float,
        analysis_start_epoch_seconds: float,
    ):
        self.report_dir = report_dir
        self.qwen_model = qwen_model
        self.analyzer_cfg = analyzer_cfg
        self.enable_ai = enable_ai
        self.ai_start_epoch_seconds = ai_start_epoch_seconds
        self.analysis_start_epoch_seconds = analysis_start_epoch_seconds
        self.lock = threading.Lock()
        self.inflight = set()
        self.processed_size = {}
        self.processed_at = {}
        self.analyzed_once = set()
        self.report_dir.mkdir(parents=True, exist_ok=True)

    @staticmethod
    # 从 capture 文件名中提取抓包起始时间（epoch 秒）。
    def _extract_capture_epoch_from_name(path: Path) -> float:
        # Expected filename: capture_YYYYMMDD_HHMMSS_xxx.pcap
        name = path.stem
        parts = name.split("_")
        if len(parts) >= 3 and parts[0] == "capture":
            ts_str = f"{parts[1]}_{parts[2]}"
            try:
                dt = datetime.strptime(ts_str, "%Y%m%d_%H%M%S")
                return dt.timestamp()
            except Exception:
                return 0.0
        return 0.0

    # 执行单个 pcap 的分析流程：增量判定、规则分析、可选 AI、写报告。
    def _process_file(self, path: Path, force: bool = False):
        if not path.exists():
            return

        capture_epoch = self._extract_capture_epoch_from_name(path)
        if (
            capture_epoch > 0
            and self.analysis_start_epoch_seconds > 0
            and capture_epoch < self.analysis_start_epoch_seconds
        ):
            with self.lock:
                self.analyzed_once.add(path)
            return

        current_size = path.stat().st_size
        now_ts = time.time()
        with self.lock:
            if path in self.inflight:
                return
            # Re-analyze only when file grows, so later traffic is not missed.
            last_size = self.processed_size.get(path, -1)
            if not force and current_size > 0 and last_size == current_size:
                return
            growth = current_size - max(last_size, 0)
            last_ts = self.processed_at.get(path, 0.0)
            interval_ok = (now_ts - last_ts) >= self.analyzer_cfg.incremental_min_interval_seconds
            growth_ok = growth >= self.analyzer_cfg.incremental_min_growth_bytes
            self.inflight.add(path)

        try:
            stable = wait_for_file_stable(path)
            if not force and not stable and not (growth_ok and interval_ok):
                print(
                    f"[DEFER] file not stable and growth({growth}) below threshold: {path}"
                )
                return

            print(f"[PROCESS] {path}")
            streaming_result = analyze_pcap_streaming(path, self.analyzer_cfg)

            summary_json = {
                "file": str(path.name),
                "capture_time": datetime.now(timezone.utc).isoformat(),
                "metrics": streaming_result["metrics"],
                "anomalies": streaming_result["anomalies"],
                "example_packets": streaming_result["example_packets"],
            }

            if self.enable_ai and (
                capture_epoch == 0.0 or capture_epoch >= self.ai_start_epoch_seconds
            ):
                llm_result = ask_qwen(summary_json, self.qwen_model)
                ai_meta = {
                    "executed": True,
                    "trigger": "auto_pipeline",
                    "model": self.qwen_model,
                }
            elif self.enable_ai:
                llm_result = {
                    "is_attack": None,
                    "threat_score": None,
                    "analysis": "该文件早于本次AI开启时间，按规则分析保留，不执行自动AI。",
                    "actions": ["如需补分析历史文件，请手动点击“AI分析”按钮。"],
                }
                ai_meta = {
                    "executed": False,
                    "trigger": "before_ai_window",
                    "model": self.qwen_model,
                }
            else:
                llm_result = {
                    "is_attack": None,
                    "threat_score": None,
                    "analysis": "当前为传统分析模式，尚未执行AI分析。",
                    "actions": ["可在Web界面点击“AI分析”按钮触发大模型研判。"],
                }
                ai_meta = {
                    "executed": False,
                    "trigger": "disabled",
                    "model": self.qwen_model,
                }
            alerts = build_alerts(summary_json, llm_result)
            final_report = {
                "input_summary": summary_json,
                "llm_assessment": llm_result,
                "alerts": alerts,
                "ai": ai_meta,
            }

            report_name = path.stem + ".analysis.json"
            out_path = self.report_dir / report_name
            out_path.write_text(
                json.dumps(final_report, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            print(f"[DONE] report written: {out_path}")
            if alerts:
                alert_log_path = self.report_dir / "alerts.jsonl"
                for alert in alerts:
                    alert_record = {
                        "time": datetime.now(timezone.utc).isoformat(),
                        "file": path.name,
                        "alert": alert,
                    }
                    with alert_log_path.open("a", encoding="utf-8") as fp:
                        fp.write(json.dumps(alert_record, ensure_ascii=False) + "\n")
                    print(f"[ALERT] {alert['level']} {alert['type']} -> {alert['message']}")
            with self.lock:
                # Save analyzed size to allow next re-analysis when file grows.
                self.processed_size[path] = current_size
                self.processed_at[path] = now_ts
                self.analyzed_once.add(path)
        finally:
            with self.lock:
                self.inflight.discard(path)

    # 定期扫描“长期存在但未分析”的 pcap，触发兜底强制分析。
    def sweep_for_stale_files(self, capture_dir: Path):
        now_ts = time.time()
        for path in capture_dir.glob("*.pcap"):
            try:
                age = now_ts - path.stat().st_mtime
            except FileNotFoundError:
                continue
            with self.lock:
                analyzed = path in self.analyzed_once
            if age >= self.analyzer_cfg.force_analyze_after_seconds and not analyzed:
                print(f"[FORCE] stale pcap forced for analysis: {path}")
                self._process_file(path, force=True)

    # 监听到新建 pcap 文件时触发分析。
    def on_created(self, event):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix.lower() == ".pcap":
            self._process_file(path)

    # 监听到 pcap 文件移动完成时触发分析。
    def on_moved(self, event):
        if event.is_directory:
            return
        path = Path(event.dest_path)
        if path.suffix.lower() == ".pcap":
            self._process_file(path)

    # 监听到 pcap 文件追加写入时触发增量分析。
    def on_modified(self, event):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix.lower() == ".pcap":
            self._process_file(path)


# 程序入口：解析参数、启动目录监听，并按周期执行补偿扫描。
def main():
    parser = argparse.ArgumentParser(
        description="Watch pcap folder and analyze with Scapy + Qwen."
    )
    parser.add_argument(
        "--capture-dir", default="../captures", help="Directory produced by C++ producer"
    )
    parser.add_argument("--report-dir", default="../reports", help="Output report directory")
    parser.add_argument("--qwen-model", default="qwen3.6-plus", help="Qwen model name")
    parser.add_argument(
        "--max-packets-per-file",
        type=int,
        default=500000,
        help="Safety cap for packets parsed from each pcap file",
    )
    parser.add_argument(
        "--syn-threshold-per-second",
        type=int,
        default=300,
        help="Threshold for SYN flood suspicion",
    )
    parser.add_argument(
        "--tcp-port-scan-min-unique-ports",
        type=int,
        default=50,
        help="TCP SYN scan: min unique dst ports per second per (src,dst)",
    )
    parser.add_argument(
        "--udp-port-scan-min-unique-ports",
        type=int,
        default=50,
        help="UDP scan: min unique dst ports per second per (src,dst)",
    )
    parser.add_argument(
        "--enable-ai",
        action="store_true",
        help="Enable AI analysis during automatic processing",
    )
    parser.add_argument(
        "--ai-start-epoch-seconds",
        type=float,
        default=0.0,
        help="Only auto-AI files captured after this epoch timestamp",
    )
    parser.add_argument(
        "--analysis-start-epoch-seconds",
        type=float,
        default=0.0,
        help="Only analyze files captured after this epoch timestamp",
    )
    parser.add_argument(
        "--force-analyze-after-seconds",
        type=int,
        default=60,
        help="Force analyze pcap if it exists longer than this",
    )
    parser.add_argument(
        "--sweep-interval-seconds",
        type=int,
        default=5,
        help="Background sweep interval for stale pcap files",
    )
    parser.add_argument(
        "--c2-channel-min-packets",
        type=int,
        default=2500,
        help="c2_channel_suspected: min TCP packets (non-std port, priv->pub)",
    )
    parser.add_argument(
        "--c2-channel-min-forward-bytes",
        type=int,
        default=120000,
        help="c2_channel_suspected: min forward (internal->external) bytes on flow",
    )
    parser.add_argument(
        "--c2-channel-max-rev-to-fwd-ratio",
        type=float,
        default=0.55,
        help="c2_channel_suspected: max reverse_bytes/forward_bytes (0-1)",
    )
    args = parser.parse_args()

    capture_dir = Path(args.capture_dir).resolve()
    report_dir = Path(args.report_dir).resolve()
    capture_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)

    print(f"Watching: {capture_dir}")
    print(f"Reports : {report_dir}")
    print(f"Model   : {args.qwen_model}")
    print(f"AI mode : {'enabled' if args.enable_ai else 'disabled'}")
    print(f"AI start epoch: {args.ai_start_epoch_seconds}")
    print(f"Analysis start epoch: {args.analysis_start_epoch_seconds}")
    print(f"Force analyze after: {args.force_analyze_after_seconds}s")

    analyzer_cfg = AnalyzerConfig(
        max_packets_per_file=args.max_packets_per_file,
        syn_threshold_per_second=args.syn_threshold_per_second,
        tcp_port_scan_min_unique_ports=args.tcp_port_scan_min_unique_ports,
        udp_port_scan_min_unique_ports=args.udp_port_scan_min_unique_ports,
        force_analyze_after_seconds=args.force_analyze_after_seconds,
        sweep_interval_seconds=args.sweep_interval_seconds,
        c2_channel_min_packets=args.c2_channel_min_packets,
        c2_channel_min_forward_bytes=args.c2_channel_min_forward_bytes,
        c2_channel_max_reverse_to_forward_ratio=args.c2_channel_max_rev_to_fwd_ratio,
    )
    handler = PcapHandler(
        report_dir=report_dir,
        qwen_model=args.qwen_model,
        analyzer_cfg=analyzer_cfg,
        enable_ai=args.enable_ai,
        ai_start_epoch_seconds=args.ai_start_epoch_seconds,
        analysis_start_epoch_seconds=args.analysis_start_epoch_seconds,
    )
    observer = Observer()
    observer.schedule(handler, str(capture_dir), recursive=False)
    observer.start()

    last_sweep_ts = 0.0
    try:
        while True:
            now_ts = time.time()
            if now_ts - last_sweep_ts >= analyzer_cfg.sweep_interval_seconds:
                handler.sweep_for_stale_files(capture_dir)
                last_sweep_ts = now_ts
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
    observer.join()


if __name__ == "__main__":
    main()
