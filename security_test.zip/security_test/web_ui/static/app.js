/**
 * Web UI 前端脚本（纯原生 JS + Chart.js）
 *
 * 主要职责：
 * - 周期拉取后端 `/api/status` 与 `/api/reports` 数据
 * - 将“报告列表 + 图表”统一用同一套筛选条件联动渲染
 * - 提供按钮操作：启动/停止抓包、启动/停止分析、手动触发 AI 分析、查看报告详情
 *
 * 注意：
 * - 这里的逻辑不做任何“安全检测算法”，只负责展示与交互；
 *   检测/告警来自 python_consumer/consumer.py 生成的 reports/*.analysis.json
 */

// DOM 快捷选择：通过 id 获取元素
const el = (id) => document.getElementById(id);

const globalMsg = el("global-msg"); // 顶部消息栏（显示启动/停止/AI分析提示）

// Chart.js 图表实例（首次创建后复用，仅更新 data）
let chart; // “威胁评分趋势（AI分析专用）”
let attackTypeChart; // 饼图：攻击类型分布
let sourceIpChart; // 饼图：攻击源 IP 分布

// 后端返回的原始报告列表（未筛选）
let allItems = [];
// 当前筛选条件作用后的列表（驱动表格与图表）
let filteredItems = [];

// 攻击类型 -> 固定颜色（保证刷新后颜色不抖动）
const ATTACK_TYPE_COLORS = {
  normal: "#868e96",
  syn_flood: "#e03131",
  port_scan: "#f08c00",
  dns_tunnel: "#7048e8",
  data_exfiltration: "#c2255c",
  c2_channel: "#495057",
  web_attack_payload: "#1098ad",
  xss_attack: "#1c7ed6",
  sql_injection: "#5f3dc4",
  command_injection: "#2b8a3e",
  path_traversal: "#d9480f",
  ssrf_attack: "#0b7285",
  malicious_upload: "#e67700",
  unknown_suspicious: "#adb5bd",
  read_error: "#343a40",
};

// 获取攻击类型对应颜色；未知类型使用稳定哈希生成 HSL，保证“同类型同色”
function colorForAttackType(type) {
  if (ATTACK_TYPE_COLORS[type]) return ATTACK_TYPE_COLORS[type];
  // 未知类型使用稳定哈希色，避免每次刷新随机变化
  let hash = 0;
  for (let i = 0; i < type.length; i += 1) {
    hash = ((hash << 5) - hash + type.charCodeAt(i)) | 0;
  }
  const hue = Math.abs(hash) % 360;
  return `hsl(${hue} 65% 48%)`;
}

// 高对比度调色盘：用于“攻击源 IP”饼图（颜色区分更明显）
const HIGH_CONTRAST_COLORS = [
  "#e03131",
  "#1971c2",
  "#2b8a3e",
  "#f08c00",
  "#7048e8",
  "#0b7285",
  "#c2255c",
  "#495057",
  "#d9480f",
  "#1c7ed6",
];

// 从“本机IP（源IP图排除）”输入框读取排除列表（支持逗号/空格分隔）
function excludedLocalIps() {
  const raw = (el("local-host-ip")?.value || "").trim();
  if (!raw) return new Set();
  return new Set(
    raw
      .split(/[,\s]+/)
      .map((x) => x.trim())
      .filter(Boolean)
  );
}

// 源 IP -> 固定颜色（通过哈希映射到高对比度调色盘）
function colorForSourceIp(ip) {
  let hash = 0;
  for (let i = 0; i < ip.length; i += 1) {
    hash = ((hash << 5) - hash + ip.charCodeAt(i)) | 0;
  }
  const idx = Math.abs(hash) % HIGH_CONTRAST_COLORS.length;
  return HIGH_CONTRAST_COLORS[idx];
}

// 统一的 API 调用封装：JSON in/out
async function callApi(url, method = "GET", body = null) {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json" },
    body: body ? JSON.stringify(body) : null,
  });
  return res.json();
}

// 设置顶部消息文案
function setMsg(text) {
  globalMsg.textContent = text || "";
}

// 避免把用户/报告内容直接注入 HTML（简单转义）
function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;")
    .replaceAll("'", "&#39;");
}

// “是否攻击”列的徽章样式映射（用于表格展示）
function attackLabelClass(label) {
  if (label.startsWith("是")) return "chip danger";
  if (label.startsWith("冲突")) return "chip warn";
  if (label === "否") return "chip ok";
  return "chip";
}

// 严重级别 -> 徽章样式（critical/high/medium/low/unknown）
function severityClass(level) {
  switch ((level || "").toLowerCase()) {
    case "critical":
      return "chip severity-critical";
    case "high":
      return "chip severity-high";
    case "medium":
      return "chip severity-medium";
    case "low":
      return "chip severity-low";
    default:
      return "chip muted";
  }
}

// 把后端的 ai_executed/ai_trigger 转成可读文案（用于表格显示）
function aiStatusText(row) {
  return row.ai_executed
    ? (row.ai_trigger === "manual_button" ? "已手动AI" : "已自动AI")
    : "仅传统分析";
}

// 根据下拉框选择计算“起始时间戳”（秒）。
// - 5m/1h/24h：直接回推固定窗口
// - all：返回 null（不做时间过滤）
function startOfWindow(rangeValue) {
  const now = Math.floor(Date.now() / 1000);
  if (rangeValue === "5m") return now - 5 * 60;
  if (rangeValue === "1h") return now - 60 * 60;
  if (rangeValue === "24h") return now - 24 * 60 * 60;
  return null;
}

// 将后端返回的 attack_types 集合填充到“攻击类型”下拉框中。
function populateAttackTypeOptions(items) {
  const select = el("filter-attack-type");
  const prev = select.value;
  const types = [...new Set(items.flatMap((x) => x.attack_types || []))].sort();
  select.innerHTML = `<option value="">全部</option>${types
    .map((t) => `<option value="${escapeHtml(t)}">${escapeHtml(t)}</option>`)
    .join("")}`;
  if (types.includes(prev)) {
    select.value = prev;
  }
}

// 把“告警源IP/目的IP”输入拆成 token，支持用逗号或空格分隔多个条件。
function parseFilterTokens(raw) {
  return String(raw || "")
    .split(/[,\s]+/)
    .map((x) => x.trim())
    .filter(Boolean);
}

// 应用筛选条件（联动：表格 + 图表）
function applyFilters() {
  const rangeValue = el("time-range").value;
  let startTs = null;
  // 时间范围：custom 使用“近 N 分钟”输入；其它使用预设窗口。
  if (rangeValue === "custom") {
    const customRaw = el("custom-minutes").value.trim();
    const customMinutes = Number(customRaw);
    const now = Math.floor(Date.now() / 1000);
    if (!Number.isNaN(customMinutes) && customMinutes > 0) {
      startTs = now - Math.floor(customMinutes * 60);
    }
  } else {
    startTs = startOfWindow(rangeValue);
  }

  const attackType = el("filter-attack-type").value.trim();
  const aiStatus = el("filter-ai-status").value;
  const scoreMinRaw = el("filter-score-min").value.trim();
  const scoreMaxRaw = el("filter-score-max").value.trim();
  const scoreMin = scoreMinRaw === "" ? null : Number(scoreMinRaw);
  const scoreMax = scoreMaxRaw === "" ? null : Number(scoreMaxRaw);
  const hasScoreMin = scoreMin !== null && !Number.isNaN(scoreMin);
  const hasScoreMax = scoreMax !== null && !Number.isNaN(scoreMax);
  const keyword = el("filter-filename-keyword").value.trim().toLowerCase();
  const srcTokens = parseFilterTokens(el("filter-src-ip").value);
  const dstTokens = parseFilterTokens(el("filter-dst-ip").value);

  filteredItems = allItems.filter((row) => {
    // 1) 时间过滤：只保留 mtime >= startTs 的报告
    if (startTs !== null && row.mtime < startTs) return false;

    // 2) 攻击类型过滤：报告 attack_types 必须包含所选类型
    if (attackType && !(row.attack_types || []).includes(attackType)) return false;

    // 3) AI 状态过滤：按 auto/manual/none 筛
    if (aiStatus === "auto" && !(row.ai_executed && row.ai_trigger !== "manual_button")) return false;
    if (aiStatus === "manual" && !(row.ai_executed && row.ai_trigger === "manual_button")) return false;
    if (aiStatus === "none" && row.ai_executed) return false;

    // 4) 评分过滤：只在用户填写 min/max 时启用（空值不参与过滤）
    const score = row.threat_score;
    if (hasScoreMin && (score === null || score === undefined || Number(score) < scoreMin)) return false;
    if (hasScoreMax && (score === null || score === undefined || Number(score) > scoreMax)) return false;

    // 5) 文件名关键词：包含即可（忽略大小写）
    if (keyword && !String(row.file || "").toLowerCase().includes(keyword)) return false;

    // 6) 告警源IP：模糊匹配（token 作为子串出现在任一 src_ip 中即可）
    if (srcTokens.length > 0) {
      const srcList = row.alert_source_ips || [];
      const srcHit = srcTokens.some((token) => srcList.some((ip) => String(ip).includes(token)));
      if (!srcHit) return false;
    }
    // 7) 告警目的IP：模糊匹配（token 作为子串出现在任一 dst_ip 中即可）
    if (dstTokens.length > 0) {
      const dstList = row.alert_destination_ips || [];
      const dstHit = dstTokens.some((token) => dstList.some((ip) => String(ip).includes(token)));
      if (!dstHit) return false;
    }

    return true;
  });

  // 统一渲染出口：表格 + 图表都由 filteredItems 驱动
  renderTable(filteredItems);
  renderChart(filteredItems);
  renderAttackTypeChart(filteredItems);
  renderSourceIpChart(filteredItems);
}

async function refreshStatus() {
  const data = await callApi("/api/status");
  el("capture-status").textContent = data.capture_running ? "运行中" : "已停止";
  el("analyzer-status").textContent = data.analyzer_running ? "运行中" : "已停止";
  el("pcap-count").textContent = String(data.capture_file_count || 0);
  el("report-count").textContent = String(data.report_file_count || 0);
}

// 渲染报告列表表格（每次筛选/刷新都会重建 tbody）
function renderTable(items) {
  const tbody = el("report-table");
  tbody.innerHTML = "";
  for (const row of items) {
    const aiStatus = aiStatusText(row);
    const hasRuleAttack = (row.attack_types || []).some(
      (t) => t && t !== "normal"
    );
    // 攻击判断标签：综合 AI 与规则结果（用于表格“是否攻击”列）
    let attackLabel = "-";
    if (row.is_attack === true && hasRuleAttack) {
      attackLabel = "是(规则+AI)";
    } else if (row.is_attack === true) {
      attackLabel = "是";
    } else if (row.is_attack === false && hasRuleAttack) {
      attackLabel = "冲突(规则是/AI否)";
    } else if (row.is_attack === false) {
      attackLabel = "否";
    } else if (hasRuleAttack || row.rule_suspected) {
      attackLabel = "是(规则)";
    }
    const typeChips = (row.attack_types && row.attack_types.length)
      ? row.attack_types.map((t) => `<span class="chip">${escapeHtml(t)}</span>`).join(" ")
      : `<span class="chip muted">normal</span>`;
    const tr = document.createElement("tr");
    // 注意：
    // - 类型 chip 使用 escapeHtml 防止注入
    // - 其它字段来自后端聚合/裁剪后的文本（仍按普通文本展示）
    tr.innerHTML = `
      <td>${row.file}</td>
      <td><span class="chip ${row.ai_executed ? "ok" : "muted"}">${aiStatus}</span></td>
      <td>${typeChips}</td>
      <td><span class="${severityClass(row.max_severity)}">${escapeHtml(row.max_severity || "unknown")}</span></td>
      <td><span class="score-badge">${row.threat_score ?? "-"}</span></td>
      <td><span class="${attackLabelClass(attackLabel)}">${attackLabel}</span></td>
      <td><div class="summary-scroll">${row.analysis || ""}</div></td>
      <td class="action-cell">
        <button data-file="${row.file}" class="view-btn action-btn">查看</button>
        <button data-file="${row.file}" class="ai-btn action-btn">AI分析</button>
      </td>
    `;
    tbody.appendChild(tr);
  }

  // “查看”按钮：拉取单条报告详情并在下方 pre 区展示 JSON
  for (const btn of document.querySelectorAll(".view-btn")) {
    btn.addEventListener("click", async () => {
      const filename = btn.dataset.file;
      const detail = await callApi(`/api/reports/${encodeURIComponent(filename)}`);
      if (detail.ok) {
        el("report-detail").textContent = JSON.stringify(detail.data, null, 2);
      } else {
        el("report-detail").textContent = detail.message || "读取失败";
      }
    });
  }
  // “AI分析”按钮：对当前报告执行手动 AI 研判，并刷新列表/图表
  for (const btn of document.querySelectorAll(".ai-btn")) {
    btn.addEventListener("click", async () => {
      const filename = btn.dataset.file;
      const result = await callApi(`/api/reports/${encodeURIComponent(filename)}/ai_analyze`, "POST", {
        qwen_model: el("qwen-model").value,
        qwen_api_key: el("qwen-api-key").value,
        qwen_base_url: el("qwen-base-url").value,
      });
      setMsg(result.message || "AI分析完成");
      await refreshReports();
    });
  }
}

// 渲染“威胁评分趋势（AI分析专用）”折线图
// 说明：当 threat_score 为空时用 0 占位，主要用于展示 AI 输出的评分变化趋势。
function renderChart(items) {
  const labels = [...items].reverse().map((x) => x.file);
  const scores = [...items].reverse().map((x) => x.threat_score ?? 0);

  const ctx = el("score-chart"); // canvas 元素
  if (!chart) { // 首次创建图表实例
    chart = new Chart(ctx, {
      type: "line",
      data: {
        labels,
        datasets: [
          {
            label: "威胁评分",
            data: scores,
            borderColor: "#1864ff",
            backgroundColor: "rgba(24,100,255,.15)",
            fill: true,
            tension: 0.25,
          },
        ],
      },
      options: {
        responsive: true,
        scales: {
          x: {
            ticks: {
              display: false,
            },
            grid: {
              display: false,
            },
          },
          y: { min: 0, max: 100 },
        },
      },
    });
  } else { // 已存在则仅更新数据，避免重复 new Chart
    chart.data.labels = labels;
    chart.data.datasets[0].data = scores;
    chart.update();
  }
}

// 饼图：攻击类型分布（统计每个 attack_type 出现的报告数量）
function renderAttackTypeChart(items) {
  const counter = {};
  for (const item of items) {
    const types = item.attack_types && item.attack_types.length ? item.attack_types : ["normal"];
    for (const t of types) {
      counter[t] = (counter[t] || 0) + 1;
    }
  }
  const labels = Object.keys(counter).sort(); // 排序保证刷新后图例顺序稳定
  const values = labels.map((k) => counter[k]);
  const colors = labels.map((t) => colorForAttackType(t));

  const ctx = el("attack-type-chart");
  if (!attackTypeChart) { // 首次创建
    attackTypeChart = new Chart(ctx, {
      type: "pie",
      data: {
        labels,
        datasets: [{ data: values, backgroundColor: colors }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        radius: "84%",
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              boxWidth: 12,
              padding: 10,
            },
          },
        },
      },
    });
  } else { // 更新数据
    attackTypeChart.data.labels = labels;
    attackTypeChart.data.datasets[0].data = values;
    // 新增攻击类型时需要同步更新颜色数组，否则会沿用旧颜色直到整页刷新。
    attackTypeChart.data.datasets[0].backgroundColor = colors;
    attackTypeChart.update();
  }
}

// 饼图：攻击源 IP 分布
// 统计 alerts 中 evidence.src_ip 的出现次数，并排除“本机IP（源IP图排除）”输入的地址。
function renderSourceIpChart(items) {
  const excludedIps = excludedLocalIps(); // Set<string>
  const counter = {};
  for (const item of items) {
    for (const ip of item.alert_source_ips || []) {
      if (excludedIps.has(ip)) continue;
      counter[ip] = (counter[ip] || 0) + 1;
    }
  }

  // 按出现次数降序，仅展示 Top 8，其余合并为 other，避免图例过长
  const sortedEntries = Object.entries(counter).sort((a, b) => b[1] - a[1]);
  const topEntries = sortedEntries.slice(0, 8);
  const otherCount = sortedEntries.slice(8).reduce((sum, x) => sum + x[1], 0);
  if (otherCount > 0) {
    topEntries.push(["other", otherCount]);
  }

  let labels = topEntries.map((x) => x[0]);
  let values = topEntries.map((x) => x[1]);
  let colors = labels.map((ip) => (ip === "other" ? "#94a3b8" : colorForSourceIp(ip)));
  // 没有任何可统计的源IP时，给一个灰色占位，避免图表报错或空白
  if (!labels.length) {
    labels = ["暂无攻击源数据"];
    values = [1];
    colors = ["#cbd5e1"];
  }

  const ctx = el("source-ip-chart");
  if (!sourceIpChart) {
    sourceIpChart = new Chart(ctx, {
      type: "pie",
      data: {
        labels,
        datasets: [{ data: values, backgroundColor: colors, borderColor: "#ffffff", borderWidth: 2 }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        radius: "84%",
        plugins: {
          legend: {
            position: "bottom",
            labels: {
              boxWidth: 12,
              padding: 10,
            },
          },
        },
      },
    });
  } else {
    sourceIpChart.data.labels = labels;
    sourceIpChart.data.datasets[0].data = values;
    sourceIpChart.data.datasets[0].backgroundColor = colors;
    sourceIpChart.update();
  }
}

// 拉取报告列表并触发一次“筛选 + 全量渲染”
async function refreshReports() {
  const data = await callApi("/api/reports");
  allItems = data.items || [];
  populateAttackTypeOptions(allItems);
  applyFilters();
}

// 绑定所有按钮与输入框事件（启动/停止/筛选联动等）
async function bindActions() {
  // 启动抓包：调用后端 /api/start_capture
  el("start-capture").addEventListener("click", async () => {
    const res = await callApi("/api/start_capture", "POST", {
      producer_exe: el("producer-exe").value,
      device_name: el("device-name").value,
      output_dir: el("capture-dir").value,
      bpf_filter: el("bpf-filter").value,
      cleanup_existing: el("cleanup-existing").value === "true",
    });
    setMsg(res.message);
    await refreshStatus();
  });

  // 停止抓包：调用后端 /api/stop_capture
  el("stop-capture").addEventListener("click", async () => {
    const res = await callApi("/api/stop_capture", "POST", {});
    setMsg(res.message);
    await refreshStatus();
  });

  // 删除 pcap 文件：调用后端 /api/clear_pcaps
  el("clear-pcaps").addEventListener("click", async () => {
    const res = await callApi("/api/clear_pcaps", "POST", {});
    setMsg(res.message);
    await refreshStatus();
    await refreshReports();
  });

  // 启动分析：调用后端 /api/start_analyzer（可选自动AI）
  el("start-analyzer").addEventListener("click", async () => {
    const res = await callApi("/api/start_analyzer", "POST", {
      python_exe: el("python-exe").value,
      capture_dir: el("ana-capture-dir").value,
      report_dir: el("report-dir").value,
      qwen_model: el("qwen-model").value,
      qwen_api_key: el("qwen-api-key").value,
      qwen_base_url: el("qwen-base-url").value,
      enable_ai: el("enable-ai").value === "true",
    });
    setMsg(res.message);
    await refreshStatus();
  });

  // 停止分析：调用后端 /api/stop_analyzer
  el("stop-analyzer").addEventListener("click", async () => {
    const res = await callApi("/api/stop_analyzer", "POST", {});
    setMsg(res.message);
    await refreshStatus();
  });

  // 清理报告并重置分析起点：调用后端 /api/reset_logs
  el("reset-logs").addEventListener("click", async () => {
    const res = await callApi("/api/reset_logs", "POST", {});
    setMsg(res.message);
    await refreshReports();
    await refreshStatus();
  });

  // “应用筛选”按钮：手动触发一次 applyFilters
  el("apply-filters").addEventListener("click", () => applyFilters());
  // “重置筛选”按钮：清空所有筛选控件并重新渲染
  el("reset-filters").addEventListener("click", () => {
    el("time-range").value = "1h";
    el("custom-minutes").value = "";
    el("filter-attack-type").value = "";
    el("filter-ai-status").value = "";
    el("filter-score-min").value = "";
    el("filter-score-max").value = "";
    el("filter-filename-keyword").value = "";
    el("filter-src-ip").value = "";
    el("filter-dst-ip").value = "";
    el("local-host-ip").value = "";
    applyFilters();
  });

  // 实时联动的控件：输入变化就触发 applyFilters
  const instantFilterIds = [
    "time-range",
    "custom-minutes",
    "filter-attack-type",
    "filter-ai-status",
    "filter-score-min",
    "filter-score-max",
    "filter-filename-keyword",
    "local-host-ip",
  ];
  for (const id of instantFilterIds) {
    el(id).addEventListener("input", () => applyFilters());
    el(id).addEventListener("change", () => applyFilters());
  }
}

// 页面入口：绑定事件、首次拉取数据，并启动 4 秒刷新一次的轮询
async function main() {
  await bindActions();
  await refreshStatus();
  await refreshReports();
  // 周期刷新：状态与报告都会随抓包/分析进程变化而更新
  setInterval(async () => {
    await refreshStatus();
    await refreshReports();
  }, 4000);
}

main();
