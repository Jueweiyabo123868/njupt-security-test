import json
import os
import requests
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

from flask import Flask, jsonify, redirect, render_template, request, session, url_for


# 项目根目录（web_ui 的上一级）。
ROOT_DIR = Path(__file__).resolve().parent.parent
# pcap 抓包输出目录。
CAPTURE_DIR = ROOT_DIR / "captures"
# 分析报告输出目录。
REPORT_DIR = ROOT_DIR / "reports"
# Python 分析脚本路径。
CONSUMER_SCRIPT = ROOT_DIR / "python_consumer" / "consumer.py"
# 可选访问密码环境变量：设置后会保护所有 /api/* 接口。
WEB_UI_PASSWORD_ENV = "WEB_UI_PASSWORD"
WEB_UI_USERNAME_ENV = "WEB_UI_USERNAME"
WEB_UI_SESSION_SECRET_ENV = "WEB_UI_SESSION_SECRET"


# 构造手动 AI 分析请求提示词，要求模型输出标准 JSON。
def build_prompt(summary_json: Dict) -> str:
    return (
        "你是网络安全分析专家。以下是系统捕获到的流量特征与异常候选，请完成：\n"
        "1) 判断是否存在攻击行为；\n"
        "2) 给出0-100的威胁评分；\n"
        "3) 说明依据（协议、源/目的地址、连接频率、payload特征）；\n"
        "4) 给出可执行处置建议。\n\n"
        "请只输出JSON，格式为：\n"
        '{"is_attack": true/false, "threat_score": 0-100, "analysis": "...", "actions": ["..."]}\n\n'
        "待分析数据如下：\n"
        f"{json.dumps(summary_json, ensure_ascii=False, indent=2)}"
    )


# 解析模型返回文本，兼容 markdown 代码块与嵌套 JSON 字符串。
def parse_qwen_json_response(text: str) -> Dict:
    content = (text or "").strip()
    if not content:
        raise ValueError("empty response")

    if content.startswith("```"):
        lines = content.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        content = "\n".join(lines).strip()

    try:
        parsed = json.loads(content)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass

    start = content.find("{")
    end = content.rfind("}")
    if start != -1 and end != -1 and end > start:
        candidate = content[start : end + 1]
        parsed = json.loads(candidate)
        if isinstance(parsed, str):
            parsed = json.loads(parsed)
        if isinstance(parsed, dict):
            return parsed

    raise ValueError("cannot parse model response as JSON object")


# 调用 Qwen 接口执行 AI 研判，失败时返回降级信息。
def ask_qwen(summary_json: Dict, model: str, api_key: str, base_url: str) -> Dict:
    if not api_key.strip():
        return {
            "is_attack": None,
            "threat_score": None,
            "analysis": "未提供 QWEN_API_KEY，无法执行AI分析。",
            "actions": ["在页面输入 QWEN_API_KEY 后重试。"],
        }

    prompt = build_prompt(summary_json)
    url = base_url.rstrip("/") + "/chat/completions"
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "你是资深网络安全分析专家。"},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.1,
    }
    headers = {
        "Authorization": f"Bearer {api_key.strip()}",
        "Content-Type": "application/json",
    }
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=90)
        response.raise_for_status()
        resp_json = response.json()
        text = (
            resp_json.get("choices", [{}])[0]
            .get("message", {})
            .get("content", "")
            .strip()
        )
        try:
            return parse_qwen_json_response(text)
        except Exception:
            return {
                "is_attack": None,
                "threat_score": None,
                "analysis": text,
                "actions": ["模型未返回标准JSON，请检查原始响应。"],
            }
    except Exception as exc:
        return {
            "is_attack": None,
            "threat_score": None,
            "analysis": f"Qwen API 调用失败: {exc}",
            "actions": ["检查 QWEN_BASE_URL / QWEN_API_KEY / 网络连通性。"],
        }


@dataclass
class ProcessState:
    # 子进程句柄；None 代表尚未启动。
    process: Optional[subprocess.Popen] = None
    # 启动命令字符串（用于状态回显）。
    command: str = ""

    # 判断子进程是否仍在运行。
    def running(self) -> bool:
        return self.process is not None and self.process.poll() is None


class RuntimeManager:
    # 初始化抓包/分析进程状态与共享锁。
    def __init__(self):
        self.capture = ProcessState()
        self.analyzer = ProcessState()
        self.lock = threading.Lock()
        self.analysis_start_epoch_seconds = 0.0

    # 统一子进程启动入口，封装工作目录与环境变量。
    def _spawn(self, cmd, cwd: Path, env: Optional[Dict[str, str]] = None) -> subprocess.Popen:
        return subprocess.Popen(
            cmd,
            cwd=str(cwd),
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            env=env,
            creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
        )

    # 清理历史 producer.exe 进程，避免重复抓包实例冲突。
    def _cleanup_existing_producers(self) -> Dict:
        try:
            result = subprocess.run(
                ["taskkill", "/IM", "producer.exe", "/F"],
                capture_output=True,
                text=True,
                check=False,
            )
            # taskkill returns non-zero when no process found; treat as non-fatal.
            return {
                "ok": True,
                "message": (result.stdout or result.stderr or "").strip(),
            }
        except Exception as exc:
            return {"ok": False, "message": f"清理旧抓包进程失败: {exc}"}

    # 清理历史 consumer.py 分析进程，避免重复分析实例冲突。
    def _cleanup_existing_analyzers(self) -> Dict:
        try:
            query = (
                "name='python.exe' and commandline like "
                "'%python_consumer\\\\consumer.py%'"
            )
            result = subprocess.run(
                ["wmic", "process", "where", query, "get", "processid", "/value"],
                capture_output=True,
                text=True,
                check=False,
            )
            output = f"{result.stdout}\n{result.stderr}"
            pids = []
            for line in output.splitlines():
                line = line.strip()
                if line.startswith("ProcessId="):
                    pid = line.split("=", 1)[1].strip()
                    if pid.isdigit():
                        pids.append(pid)

            for pid in pids:
                subprocess.run(
                    ["taskkill", "/PID", pid, "/F"],
                    capture_output=True,
                    text=True,
                    check=False,
                )

            return {
                "ok": True,
                "killed_count": len(pids),
                "message": f"已清理 {len(pids)} 个历史分析进程。",
            }
        except Exception as exc:
            return {"ok": False, "message": f"清理旧分析进程失败: {exc}"}

    # 启动抓包进程（可选先清理历史 producer 进程）。
    # 参数含义：
    # - producer_exe: C++ 抓包程序路径
    # - device_name: Npcap 网卡设备名
    # - output_dir: pcap 输出目录
    # - bpf_filter: 抓包过滤表达式
    # - cleanup_existing: 启动前是否杀掉旧 producer
    def start_capture(
        self,
        producer_exe: str,
        device_name: str,
        output_dir: str,
        bpf_filter: str,
        cleanup_existing: bool,
    ) -> Dict:
        with self.lock:
            if self.capture.running():
                return {"ok": False, "message": "抓包进程已在运行。"}

            cleanup_msg = ""
            if cleanup_existing:
                cleanup_result = self._cleanup_existing_producers()
                if not cleanup_result["ok"]:
                    return {"ok": False, "message": cleanup_result["message"]}
                cleanup_msg = "已自动清理历史 producer 进程。"

            cmd = [producer_exe, device_name, output_dir]
            if bpf_filter.strip():
                cmd.append(bpf_filter.strip())

            try:
                proc = self._spawn(cmd, ROOT_DIR)
                self.capture = ProcessState(proc, " ".join(cmd))
                msg = "抓包进程已启动。"
                if cleanup_msg:
                    msg = f"{cleanup_msg} {msg}"
                return {"ok": True, "message": msg, "command": self.capture.command}
            except Exception as exc:
                return {"ok": False, "message": f"启动抓包失败: {exc}"}

    # 停止抓包进程。
    def stop_capture(self) -> Dict:
        with self.lock:
            if not self.capture.running():
                return {"ok": False, "message": "抓包进程未运行。"}
            self.capture.process.terminate()
            return {"ok": True, "message": "抓包进程已停止。"}

    # 启动分析进程并传入 AI 相关参数。
    # python_exe: Python 可执行程序
    # capture_dir/report_dir: 输入输出目录
    # qwen_model/qwen_api_key/qwen_base_url: AI 配置
    # enable_ai: 是否自动 AI 研判
    def start_analyzer(
        self,
        python_exe: str,
        capture_dir: str,
        report_dir: str,
        qwen_model: str,
        qwen_api_key: str,
        qwen_base_url: str,
        enable_ai: bool,
    ) -> Dict:
        with self.lock:
            # 第一层保护：已有 analyzer 运行时不重复启动。
            if self.analyzer.running():  # 防止重复拉起分析进程，避免同目录被多个 consumer 同时写报告
                return {"ok": False, "message": "分析进程已在运行。"}
            cleanup_result = self._cleanup_existing_analyzers()
            if not cleanup_result["ok"]:  # 历史进程清理失败时直接返回，避免新旧分析进程并存
                return {"ok": False, "message": cleanup_result["message"]}

            cmd = [
                python_exe,
                str(CONSUMER_SCRIPT),
                "--capture-dir",
                capture_dir,
                "--report-dir",
                report_dir,
                "--qwen-model",
                qwen_model,
            ]
            # 开启自动 AI 时，为这次启动记录“AI起点时间”。
            if enable_ai:  # 仅在用户开启自动AI时下发开关和起点时间参数
                cmd.append("--enable-ai")
                cmd.extend(["--ai-start-epoch-seconds", str(time.time())])
            # 若用户重置过分析起点，则把时间窗参数下发给 consumer。
            if self.analysis_start_epoch_seconds > 0:  # 只分析重置之后捕获到的文件，避免旧数据混入
                cmd.extend(
                    [
                        "--analysis-start-epoch-seconds",
                        str(self.analysis_start_epoch_seconds),
                    ]
                )
            try:
                env = os.environ.copy()
                if qwen_api_key.strip():  # 页面输入了 key 才覆盖环境变量，空值不覆盖
                    env["QWEN_API_KEY"] = qwen_api_key.strip()
                if qwen_base_url.strip():  # 页面输入了 base_url 才覆盖默认地址
                    env["QWEN_BASE_URL"] = qwen_base_url.strip()

                proc = self._spawn(cmd, ROOT_DIR, env=env)
                self.analyzer = ProcessState(proc, " ".join(cmd))
                prefix = ""
                if cleanup_result.get("killed_count", 0) > 0:  # 若确实清理过旧进程，则把信息拼到返回文案
                    prefix = f"{cleanup_result['message']} "
                return {
                    "ok": True,
                    "message": f"{prefix}分析进程已启动。",
                    "command": self.analyzer.command,
                }
            except Exception as exc:
                return {"ok": False, "message": f"启动分析失败: {exc}"}

    # 清理报告与日志，并重置“分析起点时间”。
    def reset_logs_and_analysis_start(self) -> Dict:
        with self.lock:
            if self.analyzer.running():
                return {"ok": False, "message": "请先停止分析进程后再清理日志。"}
            REPORT_DIR.mkdir(parents=True, exist_ok=True)
            removed = 0
            for p in REPORT_DIR.glob("*.analysis.json"):
                try:
                    p.unlink()
                    removed += 1
                except Exception:
                    pass
            for extra in ["alerts.jsonl", "analyzer.log"]:
                p = REPORT_DIR / extra
                if p.exists():
                    try:
                        p.unlink()
                    except Exception:
                        pass
            self.analysis_start_epoch_seconds = time.time()
            return {
                "ok": True,
                "message": f"已清理 {removed} 个报告，并重置分析起点。",
                "analysis_start_epoch_seconds": self.analysis_start_epoch_seconds,
            }

    # 删除 captures 目录下 pcap 文件（需先停止抓包）。
    def clear_capture_files(self) -> Dict:
        with self.lock:
            if self.capture.running():
                return {"ok": False, "message": "请先停止抓包进程后再删除 pcap 文件。"}
            CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
            removed = 0
            for p in CAPTURE_DIR.glob("*.pcap"):
                try:
                    p.unlink()
                    removed += 1
                except Exception:
                    pass
            return {"ok": True, "message": f"已删除 {removed} 个 pcap 文件。"}

    # 停止分析进程。
    def stop_analyzer(self) -> Dict:
        with self.lock:
            if not self.analyzer.running():
                return {"ok": False, "message": "分析进程未运行。"}
            self.analyzer.process.terminate()
            return {"ok": True, "message": "分析进程已停止。"}

    # 返回当前抓包/分析进程状态。
    def status(self) -> Dict:
        return {
            "capture_running": self.capture.running(),
            "capture_command": self.capture.command,
            "analyzer_running": self.analyzer.running(),
            "analyzer_command": self.analyzer.command,
        }


runtime = RuntimeManager()
app = Flask(__name__, template_folder="templates", static_folder="static")
app.secret_key = os.getenv(WEB_UI_SESSION_SECRET_ENV, "change-this-in-production")


@app.before_request
def protect_api_with_password():
    expected = os.getenv(WEB_UI_PASSWORD_ENV, "B23041330").strip()

    # 放行登录页和静态资源。
    if request.path.startswith("/static/") or request.path == "/login":
        return None

    # 已登录会话直接通过。
    if session.get("ui_authed") is True:
        return None

    # API 返回 JSON 未授权；页面请求跳到登录页。
    if request.path.startswith("/api/"):
        return jsonify({"ok": False, "message": "未授权：请先登录。"}), 401
    return redirect(url_for("login", next=request.path))


@app.route("/login", methods=["GET", "POST"])
def login():
    expected_user = os.getenv(WEB_UI_USERNAME_ENV, "B23041327").strip()
    expected_pwd = os.getenv(WEB_UI_PASSWORD_ENV, "B23041330").strip()

    error = ""
    # 进入登录页时清空旧会话，确保每次进入都需重新登录。
    if request.method == "GET":
        session.pop("ui_authed", None)
    next_path = request.args.get("next", "/dashboard")
    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = (request.form.get("password") or "").strip()
        if username == expected_user and password == expected_pwd:
            session["ui_authed"] = True
            return redirect(next_path or "/dashboard")
        error = "账号或密码错误，请重试。"
    return render_template("login.html", error=error, next_path=next_path)


@app.route("/logout", methods=["POST"])
def logout():
    session.pop("ui_authed", None)
    return redirect(url_for("login"))


# 聚合报告列表：提取展示字段并做攻击类型/严重级别归一化。
# 返回给前端的每行字段都在这里统一拼装。
def list_reports():
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    items = []

    # 去掉 *_suspected 后缀，用于 UI 展示更简洁的攻击类型名。
    def _display_attack_type(raw_type: str) -> str:
        if not raw_type:
            return "unknown_suspicious"
        if raw_type.endswith("_suspected"):
            return raw_type[: -len("_suspected")]
        return raw_type

    # 归一化严重级别字段，限定在 critical/high/medium/low/unknown。
    def _normalize_severity(value: str) -> str:
        level = (value or "").strip().lower()
        if level in {"critical", "high", "medium", "low"}:
            return level
        return "unknown"

    # 按报告修改时间倒序读取，保证列表最上面是最新分析结果。
    for p in sorted(REPORT_DIR.glob("*.analysis.json"), key=lambda x: x.stat().st_mtime, reverse=True):
        try:
            data = json.loads(p.read_text(encoding="utf-8"))  # 读取并解析单个报告 JSON
            llm = data.get("llm_assessment", {})  # AI 评估结果区
            ai = data.get("ai", {})  # AI 执行元信息区（是否执行、触发方式等）
            summary = data.get("input_summary", {})  # 规则分析摘要区
            anomalies = summary.get("anomalies", [])  # 原始异常明细（consumer 产出）
            alerts = data.get("alerts", [])  # 聚合告警列表（build_alerts 产出）
            severity_rank = {"critical": 4, "high": 3, "medium": 2, "low": 1, "unknown": 0}
            severities = sorted(
                {
                    _normalize_severity(a.get("severity") or a.get("level", "unknown"))
                    for a in alerts
                },
                key=lambda s: severity_rank.get(s, 0),  # 用映射分值排序，便于取最高等级
                reverse=True,  # 倒序：critical 在最前
            )
            alert_source_ips = sorted(
                {
                    (a.get("evidence", {}) or {}).get("src_ip", "")
                    for a in alerts
                    if (a.get("evidence", {}) or {}).get("src_ip", "")
                }
            )
            alert_destination_ips = sorted(
                {
                    (a.get("evidence", {}) or {}).get("dst_ip", "")
                    for a in alerts
                    if (a.get("evidence", {}) or {}).get("dst_ip", "")
                }
            )
            # 有 anomalies 或 alerts 均视为“规则疑似命中”。
            rule_suspected = bool(anomalies) or bool(alerts)  # 给前端“规则是否命中”总开关
            attack_types = sorted(
                {
                    _display_attack_type(
                        a.get("rule_type") or a.get("attack_type") or "unknown_suspicious"
                    )
                    for a in alerts
                    if (a.get("rule_type") or a.get("attack_type"))
                }
            )
            # 多类型并存时去掉 normal，避免把“正常”稀释真实攻击标签。
            if len(attack_types) > 1 and "normal" in attack_types:  # 仅当还有其他类型时移除 normal
                attack_types = [t for t in attack_types if t != "normal"]
            # 理论上有命中却没有类型时，给一个兜底类型。
            if not attack_types and rule_suspected:  # 防止前端空白，给 unknown_suspicious 兜底
                attack_types = ["unknown_suspicious"]
            items.append(
                {
                    "file": p.name,
                    "mtime": int(p.stat().st_mtime),  # 用于时间筛选器与图表横轴排序
                    "threat_score": llm.get("threat_score"),
                    "is_attack": llm.get("is_attack"),
                    "analysis": llm.get("analysis", "")[:180],  # 表格摘要只展示前 180 字
                    "ai_executed": bool(ai.get("executed", False)),  # UI 用于区分“自动/手动/未执行”
                    "ai_trigger": ai.get("trigger", "unknown"),  # manual_button / auto_pipeline / disabled
                    "rule_suspected": rule_suspected,
                    "attack_types": attack_types,
                    "primary_attack_type": attack_types[0] if attack_types else "normal",  # 兼容旧 UI 主类型字段
                    "severities": severities,
                    "max_severity": severities[0] if severities else "unknown",  # 排序后第一个即最高等级
                    "alert_source_ips": alert_source_ips,  # 给“源IP筛选/饼图”使用
                    "alert_destination_ips": alert_destination_ips,  # 给“目的IP筛选”使用
                }
            )
        except Exception:  # 单个报告损坏/解析失败时，返回兜底条目而不是中断整个列表
            items.append(
                {
                    "file": p.name,
                    "mtime": int(p.stat().st_mtime),
                    "threat_score": None,
                    "is_attack": None,
                    "analysis": "报告读取失败",
                    "ai_executed": False,
                    "ai_trigger": "unknown",
                    "rule_suspected": False,
                    "attack_types": [],
                    "primary_attack_type": "read_error",
                    "severities": ["unknown"],
                    "max_severity": "unknown",
                    "alert_source_ips": [],
                    "alert_destination_ips": [],
                }
            )
    return items


@app.route("/")
def index():
    return redirect(url_for("login"))


@app.route("/dashboard")
# 首页：返回主控制台页面。
def dashboard():
    return render_template("index.html")


@app.route("/api/status")
# 查询系统状态（进程状态 + pcap/报告文件数）。
def api_status():
    CAPTURE_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    pcap_files = list(CAPTURE_DIR.glob("*.pcap"))
    return jsonify(
        {
            **runtime.status(),
            "capture_file_count": len(pcap_files),
            "report_file_count": len(list(REPORT_DIR.glob("*.analysis.json"))),
        }
    )


@app.route("/api/start_capture", methods=["POST"])
# 启动抓包 API。
def api_start_capture():
    payload = request.get_json(force=True)
    producer_exe = payload.get("producer_exe", str(ROOT_DIR / "cpp_producer" / "build" / "Release" / "producer.exe"))
    device_name = payload.get("device_name", "").strip()
    output_dir = payload.get("output_dir", str(CAPTURE_DIR))
    bpf_filter = payload.get("bpf_filter", "tcp or udp")
    cleanup_existing = bool(payload.get("cleanup_existing", True))
    if not device_name:
        return jsonify({"ok": False, "message": "device_name 不能为空。"}), 400
    return jsonify(
        runtime.start_capture(
            producer_exe, device_name, output_dir, bpf_filter, cleanup_existing
        )
    )


@app.route("/api/stop_capture", methods=["POST"])
# 停止抓包 API。
def api_stop_capture():
    return jsonify(runtime.stop_capture())


@app.route("/api/start_analyzer", methods=["POST"])
# 启动分析 API。
def api_start_analyzer():
    payload = request.get_json(force=True)
    python_exe = payload.get("python_exe", "python")
    capture_dir = payload.get("capture_dir", str(CAPTURE_DIR))
    report_dir = payload.get("report_dir", str(REPORT_DIR))
    qwen_model = payload.get("qwen_model", "qwen3.6-plus")
    qwen_api_key = payload.get("qwen_api_key", "")
    qwen_base_url = payload.get("qwen_base_url", "https://dashscope.aliyuncs.com/compatible-mode/v1")
    raw_enable_ai = payload.get("enable_ai", False)
    if isinstance(raw_enable_ai, str):
        enable_ai = raw_enable_ai.strip().lower() in {"1", "true", "yes", "on"}
    else:
        enable_ai = bool(raw_enable_ai)
    return jsonify(
        runtime.start_analyzer(
            python_exe,
            capture_dir,
            report_dir,
            qwen_model,
            qwen_api_key,
            qwen_base_url,
            enable_ai,
        )
    )


@app.route("/api/stop_analyzer", methods=["POST"])
# 停止分析 API。
def api_stop_analyzer():
    return jsonify(runtime.stop_analyzer())


@app.route("/api/reset_logs", methods=["POST"])
# 清理报告与日志并重置分析起点 API。
def api_reset_logs():
    return jsonify(runtime.reset_logs_and_analysis_start())


@app.route("/api/clear_pcaps", methods=["POST"])
# 删除 pcap 文件 API。
def api_clear_pcaps():
    return jsonify(runtime.clear_capture_files())


@app.route("/api/reports")
# 获取报告列表 API。
def api_reports():
    return jsonify({"items": list_reports()})


@app.route("/api/reports/<path:filename>")
# 获取单个报告详情 API。
def api_report_detail(filename):
    target = REPORT_DIR / filename
    if not target.exists():
        return jsonify({"ok": False, "message": "报告不存在"}), 404
    try:
        data = json.loads(target.read_text(encoding="utf-8"))
        return jsonify({"ok": True, "data": data})
    except Exception as exc:
        return jsonify({"ok": False, "message": f"报告读取失败: {exc}"}), 500


@app.route("/api/reports/<path:filename>/ai_analyze", methods=["POST"])
# 对指定报告执行手动 AI 分析并回写结果 API。
def api_report_ai_analyze(filename):
    payload = request.get_json(force=True)
    qwen_model = payload.get("qwen_model", "qwen3.6-plus")
    qwen_api_key = payload.get("qwen_api_key", "")
    qwen_base_url = payload.get(
        "qwen_base_url", "https://dashscope.aliyuncs.com/compatible-mode/v1"
    )

    target = REPORT_DIR / filename
    if not target.exists():
        return jsonify({"ok": False, "message": "报告不存在"}), 404
    try:
        report = json.loads(target.read_text(encoding="utf-8"))
        summary = report.get("input_summary", {})
        llm_result = ask_qwen(summary, qwen_model, qwen_api_key, qwen_base_url)
        report["llm_assessment"] = llm_result
        report["ai"] = {
            "executed": True,
            "trigger": "manual_button",
            "model": qwen_model,
        }
        target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        return jsonify({"ok": True, "message": f"{filename} AI分析完成", "llm_assessment": llm_result})
    except Exception as exc:
        return jsonify({"ok": False, "message": f"AI分析失败: {exc}"}), 500


if __name__ == "__main__":
    print(f"[AUTH] username env: {WEB_UI_USERNAME_ENV} (default: B23041327)")
    print(f"[AUTH] password env: {WEB_UI_PASSWORD_ENV} (default: B23041330)")
    app.run(host="0.0.0.0", port=7860, debug=False)
